<?php include "db.php"; ?>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $numer = $_POST['numer_lotu'];
    $wylot = $_POST['miejsce_wylotu'];
    $przylot = $_POST['miejsce_przylotu'];
    $data = $_POST['data_lotu'];
    $imie_nazwisko = $_POST['imie_nazwisko'];

    $sql = "INSERT INTO bilety (numer_lotu, miejsce_wylotu, miejsce_przylotu, data_lotu, imie_nazwisko)
            VALUES ('$numer', '$wylot', '$przylot', '$data', '$imie_nazwisko')";

    $conn->query($sql);

    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Dodaj bilet</title>
</head>
<body>

<h2>Dodaj bilet</h2>
<form method="POST">
    <input type="text" name="numer_lotu" placeholder="Numer lotu: " required><br><br>
    <input type="text" name="miejsce_wylotu" placeholder="Miejsce wylotu: " required><br><br>
    <input type="text" name="miejsce_przylotu" placeholder="Miejsce przylotu: " required><br><br>
    <input type="date" name="data_lotu" placeholder="Data lotu: " required><br><br>
    <input type="text" name="imie_nazwisko" placeholder="Imie i Nazwisko: " required><br><br>

    <button type="submit">Zapisz</button>
</form>

</body>
</html>
