<?php include "db.php"; ?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Lista biletów</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h2>Lista zapisanych biletów</h2>
<a href="dodaj.php">Dodaj bilet</a><br><br>

<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Numer lotu</th>
        <th>Wylot</th>
        <th>Przylot</th>
        <th>Data</th>
        <th>Imie i Nazwisko</th>
        <th>Akcje</th>
    </tr>

<?php
$result = $conn->query("SELECT * FROM bilety");
while($row = $result->fetch_assoc()):
?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= $row['numer_lotu'] ?></td>
    <td><?= $row['miejsce_wylotu'] ?></td>
    <td><?= $row['miejsce_przylotu'] ?></td>
    <td><?= $row['data_lotu'] ?></td>
    <td><?= $row['imie_nazwisko'] ?></td>
    <td>
        <a href="edytuj.php?id=<?= $row['id'] ?>">Edytuj</a>
        <a href="usun.php?id=<?= $row['id'] ?>" onclick="return confirm('Usunąć bilet?')">Usuń</a>
    </td>
</tr>
<?php endwhile; ?>

</table>

</body>
</html>
