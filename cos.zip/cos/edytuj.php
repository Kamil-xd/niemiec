<?php include "db.php"; ?>

<?php
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM bilety WHERE id=$id");
$row = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $numer = $_POST['numer_lotu'];
    $wylot = $_POST['miejsce_wylotu'];
    $przylot = $_POST['miejsce_przylotu'];
    $data = $_POST['data_lotu'];
    $imie_nazwisko = $_POST['imie_nazwisko'];

    $sql = "UPDATE bilety SET
        numer_lotu='$numer',
        miejsce_wylotu='$wylot',
        miejsce_przylotu='$przylot',
        data_lotu='$data',
        imie_nazwisko='$imie_nazwisko'
        WHERE id=$id";

    $conn->query($sql);

    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Edytuj bilet</title>
</head>
<body>

<h2>Edytuj bilet</h2>

<form method="POST">
    <input type="text" name="numer_lotu" placeholder="Numer lotu: " value="<?= $row['numer_lotu'] ?>" required><br><br>
    <input type="text" name="miejsce_wylotu" placeholder="Miejsce wylotu: " value="<?= $row['miejsce_wylotu'] ?>" required><br><br>
    <input type="text" name="miejsce_przylotu" placeholder="Miejsce przylotu: "  value="<?= $row['miejsce_przylotu'] ?>" required><br><br>
    <input type="date" name="data_lotu" placeholder="Data lotu: "  value="<?= $row['data_lotu'] ?>" required><br><br>
    <input type="text" name="imie_nazwisko" placeholder="Imie i Nazwisko: "  value="<?= $row['imie_nazwisko'] ?>" required><br><br>

    <button type="submit">Zapisz zmiany</button>
</form>

</body>
</html>
