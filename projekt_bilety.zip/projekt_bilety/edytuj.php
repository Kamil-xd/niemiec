<?php include "db_conn.php"; ?>

<?php
$id = $_GET['id'];

$result = mysqli_query($conn, "SELECT * FROM loty WHERE id=$id");
$row = mysqli_fetch_assoc($result);

if (!empty($_POST)) {

    $numer = $_POST['numer_lotu'];
    $wylot = $_POST['miejsce_wylotu'];
    $przylot = $_POST['miejsce_przylotu'];
    $data = $_POST['data_lotu'];
    $imie_nazwisko = $_POST['imie_nazwisko'];

    $sql = "UPDATE loty SET numer_lotu='$numer', miejsce_wylotu='$wylot', miejsce_przylotu='$przylot', data_lotu='$data', imie_nazwisko='$imie_nazwisko' WHERE id=$id";

    mysqli_query($conn, $sql);

    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<form method="POST">
    <input type="text" name="numer_lotu" placeholder="Numer lotu: "><br>
    <input type="text" name="miejsce_wylotu" placeholder="Miejsce wylotu: "><br>
    <input type="text" name="miejsce_przylotu" placeholder="Miejsce przylotu: "><br>
    <input type="date" name="data_lotu" placeholder="Data lotu: "><br>
    <input type="text" name="imie_nazwisko" placeholder="Imie i Nazwisko: "><br>
    <input type="submit">
</form>

</body>
</html>










