<?php include "db_conn.php"; ?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<a href="dodaj.php" id="dodaj">dodaj</a><br>

<table>
    <tr>
        <th>id</th>
        <th>numer lotu</th>
        <th>wylot</th>
        <th>przylot</th>
        <th>data</th>
        <th>imie i nazwisko</th>
    </tr>

<?php
$result = mysqli_query($conn, "SELECT * FROM loty");

while ($row = mysqli_fetch_assoc($result)){
?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= $row['numer_lotu'] ?></td>
    <td><?= $row['miejsce_wylotu'] ?></td>
    <td><?= $row['miejsce_przylotu'] ?></td>
    <td><?= $row['data_lotu'] ?></td>
    <td><?= $row['imie_nazwisko'] ?></td>
    <td>
        <a href="edytuj.php?id=<?= $row['id'] ?>">edytuj</a>
        <a href="usun.php?id=<?= $row['id'] ?>">usuń</a>
    </td>
</tr>
<?php } ?>

</table>

</body>
</html>

