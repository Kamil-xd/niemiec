<?php 
    include "db_conn.php";


    if (!empty($_POST)) {
        $numer = $_POST['numer_lotu'];
        $wylot = $_POST['miejsce_wylotu'];
        $przylot = $_POST['miejsce_przylotu'];
        $data = $_POST['data_lotu'];
        $imie_nazwisko = $_POST['imie_nazwisko'];

        $sql = "INSERT INTO loty (numer_lotu, miejsce_wylotu, miejsce_przylotu, data_lotu, imie_nazwisko)
                VALUES ('$numer', '$wylot', '$przylot', '$data', '$imie_nazwisko')";

        mysqli_query($conn, $sql);
        header("Location: index.php");
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>


<form method="POST">
    <input type="text" name="numer_lotu" placeholder="numer lotu" require>
    <br>

    <input type="text" name="miejsce_wylotu" placeholder="miejsce wylotu" require>
    <br>

    <input type="text" name="miejsce_przylotu" placeholder="miejsce przylotu" require>
    <br>

    <input type="date" name="data_lotu" placeholder="data lotu" require>
    <br>

    <input type="text" name="imie_nazwisko" placeholder="imie i nazwisko" require>
    <br>

    <input type="submit">
</form>

</body>
</html>