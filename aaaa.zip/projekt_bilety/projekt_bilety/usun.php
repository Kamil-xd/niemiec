<?php   
include "db_conn.php"; 

$id = $_GET['id'];

mysqli_query($conn, "DELETE FROM loty WHERE id=$id");
header("Location: index.php");
?>

